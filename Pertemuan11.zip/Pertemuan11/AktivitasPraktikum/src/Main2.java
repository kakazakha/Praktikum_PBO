public class Main2 {
    public static void main(String[] args) {
        Mobil m = new Mobil("G-Wagon");
        m.produksiKendaraan();
        m.nyalakanMesin();
        m.matikanMesin();
        m.pemilikKendaraan("kaka");
    }
}
