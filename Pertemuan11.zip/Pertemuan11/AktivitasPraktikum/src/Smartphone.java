public class Smartphone implements Gadget{
    
    @Override
    public void hidupkan() {
        System.out.println("HP menyala");
    }
    
}
