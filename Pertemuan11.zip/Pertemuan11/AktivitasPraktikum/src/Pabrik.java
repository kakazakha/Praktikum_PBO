public interface Pabrik {
    void produksiKendaraan();
}
