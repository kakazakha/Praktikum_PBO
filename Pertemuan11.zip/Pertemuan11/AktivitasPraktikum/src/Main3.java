public class Main3 {
    
    public static void main(String[] args) {
        Smartphone hp = new Smartphone();

        hp.hidupkan();
        hp.cekBaterai();

        Gadget.info();

    }
}
